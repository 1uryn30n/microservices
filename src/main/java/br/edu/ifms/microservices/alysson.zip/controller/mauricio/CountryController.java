package br.edu.ifms.microservices.controller.available;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ifms.microservices.model.available.Country;
import br.edu.ifms.microservices.service.available.CountryService;

@RestController
@RequestMapping(value = "/country")
public class CountryController {

    @Autowired
    CountryService service;


    @GetMapping("/list")
    public ResponseEntity<List<Country>> getAll() {
        return ResponseEntity.ok(this.service.getAll());
    }


    @GetMapping("/id/{id}")
    public ResponseEntity<Country> getCountry(@PathVariable("id") long id) {
        return ResponseEntity.ok(this.service.getOneById(id));
    }


    @GetMapping("/name/{name}")
    public ResponseEntity<List<Country>> getByName(@PathVariable("name") String name) {
        return ResponseEntity.ok(this.service.getByName(name));
    }
}
