package br.edu.ifms.microservices.controller.available;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ifms.microservices.model.available.State;
import br.edu.ifms.microservices.service.available.StateService;

@RestController
@RequestMapping(value = "/state")
public class StateController {

    @Autowired
    StateService service;


    @GetMapping("/list")
    public ResponseEntity<List<State>> getAll() {
        return ResponseEntity.ok(this.service.getAll());
    }


    @GetMapping("/id/{id}")
    public ResponseEntity<State> getState(@PathVariable("id") long id) {
        return ResponseEntity.ok(this.service.getOneById(id));
    }


    @GetMapping("/name/{name}")
    public ResponseEntity<List<State>> getByName(@PathVariable("name") String name) {
        return ResponseEntity.ok(this.service.getByName(name));
    }
}
