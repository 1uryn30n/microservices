package br.edu.ifms.microservices.controller.available;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.edu.ifms.microservices.model.available.Car;
import br.edu.ifms.microservices.service.available.CarService;

@RestController
@RequestMapping(value = "/car")
public class CarController {

    @Autowired
    CarService service;


    @GetMapping("/list")
    public ResponseEntity<List<Car>> getAll() {
        return ResponseEntity.ok(this.service.getAll());
    }


    @GetMapping("/id/{id}")
    public ResponseEntity<Car> getCar(@PathVariable("id") long id) {
        return ResponseEntity.ok(this.service.getOneById(id));
    }


    @GetMapping("/name/{name}")
    public ResponseEntity<List<Car>> getByName(@PathVariable("name") String name) {
        return ResponseEntity.ok(this.service.getByName(name));
    }
}
